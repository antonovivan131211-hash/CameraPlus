package ru.tpcamera.screen;

import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_357;

public final class ConfigSliderWidget extends class_357 {
	private final String labelKey;
	private final double min;
	private final double max;
	private final double step;
	private final Consumer<Double> onChanged;

	public ConfigSliderWidget(int x, int y, int width, int height, String labelKey, double min, double max, double step, double currentValue, Consumer<Double> onChanged) {
		super(x, y, width, height, class_2561.method_43473(), 0.0D);
		this.labelKey = labelKey;
		this.min = min;
		this.max = max;
		this.step = step;
		this.onChanged = onChanged;
		this.field_22753 = toSliderValue(currentValue);
		this.method_25346();
	}

	public void setActualValueSilently(double actualValue) {
		this.field_22753 = toSliderValue(actualValue);
		this.method_25346();
	}

	private double getActualValue() {
		double denormalized = class_3532.method_16436(this.field_22753, this.min, this.max);
		return snap(denormalized);
	}

	private double toSliderValue(double actualValue) {
		double clamped = class_3532.method_15350(snap(actualValue), this.min, this.max);
		if (this.max <= this.min) {
			return 0.0D;
		}

		return (clamped - this.min) / (this.max - this.min);
	}

	private double snap(double value) {
		if (this.step <= 0.0D) {
			return value;
		}

		return Math.round(value / this.step) * this.step;
	}

	private static String formatValue(double value) {
		return String.format(Locale.ROOT, "%.2f", value);
	}

	@Override
	protected void method_25346() {
		this.method_25355(class_2561.method_43469(
			"screen.tpcamera.slider",
			class_2561.method_43471(this.labelKey),
			formatValue(this.getActualValue())
		));
	}

	@Override
	protected void method_25344() {
		double actualValue = this.getActualValue();
		this.field_22753 = toSliderValue(actualValue);
		this.onChanged.accept(actualValue);
		this.method_25346();
	}
}