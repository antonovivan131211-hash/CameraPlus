package ru.tpcamera;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_5498;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.tpcamera.camera.DynamicPreset;
import ru.tpcamera.command.CameraCommand;
import ru.tpcamera.config.CameraConfig;
import ru.tpcamera.config.CameraConfigManager;
import ru.tpcamera.mixin.client.GameRendererAccessor;
import ru.tpcamera.screen.CameraConfigScreen;

public final class ThirdPersonCameraClient implements ClientModInitializer {
	public static final String MOD_ID = "tpcamera";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static class_304 openConfigKey;
	private static class_304 cyclePresetKey;

	@Override
	public void onInitializeClient() {
		CameraConfigManager.load();
		CameraCommand.register();

		openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.tpcamera.open_config",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_O,
			"category.tpcamera.general"
		));
		cyclePresetKey = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.tpcamera.cycle_preset",
			class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_P,
			"category.tpcamera.general"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openConfigKey.method_1436()) {
				openConfigScreen(client);
			}
			while (cyclePresetKey.method_1436()) {
				cycleDynamicPreset(client);
			}
		});

		HudRenderCallback.EVENT.register(ThirdPersonCameraClient::renderThirdPersonCrosshair);

		LOGGER.info("TP Камера запущена. Открой настройки: O или /tpcam gui.");
	}

	private static void renderThirdPersonCrosshair(class_332 context, float tickDelta) {
		class_310 client = class_310.method_1551();
		if (!shouldUseThirdPersonCrosshair(client) || client.field_1755 != null) {
			return;
		}

		class_243 targetPosition = findTargetPosition(client, tickDelta);
		if (targetPosition == null) {
			return;
		}

		class_241 screenPosition = projectToScreen(client, targetPosition, tickDelta);
		if (screenPosition == null) {
			return;
		}

		drawCrosshair(context, Math.round(screenPosition.field_1343), Math.round(screenPosition.field_1342));
	}

	public static boolean shouldUseThirdPersonCrosshair(class_310 client) {
		if (client.field_1724 == null || client.field_1687 == null || client.field_1690.field_1842 || client.field_1755 != null) {
			return false;
		}

		class_5498 perspective = client.field_1690.method_31044();
		if (perspective.method_31034()) {
			return false;
		}

		CameraConfig config = CameraConfigManager.getConfig();
		return config.enabled && config.showThirdPersonCrosshair;
	}

	private static class_243 findTargetPosition(class_310 client, float tickDelta) {
		class_1297 player = client.field_1724;
		if (player == null || client.field_1687 == null) {
			return null;
		}

		double reachDistance = client.field_1761 != null ? client.field_1761.method_2904() : 4.5D;
		reachDistance = Math.max(4.5D, reachDistance);

		class_243 start = player.method_5836(tickDelta);
		class_243 direction = player.method_5828(tickDelta);
		class_243 end = start.method_1019(direction.method_1021(reachDistance));

		class_3965 blockHit = client.field_1687.method_17742(new class_3959(
			start,
			end,
			class_3959.class_3960.field_17559,
			class_3959.class_242.field_1348,
			player
		));

		double bestDistanceSq = reachDistance * reachDistance;
		class_243 bestPosition = end;
		if (blockHit.method_17783() != class_239.class_240.field_1333) {
			bestDistanceSq = start.method_1025(blockHit.method_17784());
			bestPosition = blockHit.method_17784();
		}

		class_238 searchBox = player.method_5829().method_18804(direction.method_1021(reachDistance)).method_1014(1.0D);
		class_3966 entityHit = class_1675.method_18075(
			player,
			start,
			end,
			searchBox,
			entity -> !entity.method_7325() && entity.method_5863() && entity != player,
			bestDistanceSq
		);

		if (entityHit != null) {
			return entityHit.method_17784();
		}

		return bestPosition;
	}

	private static class_241 projectToScreen(class_310 client, class_243 targetPosition, float tickDelta) {
		class_4184 camera = client.field_1773.method_19418();
		class_243 cameraPos = camera.method_19326();
		class_243 cameraToTarget = targetPosition.method_1020(cameraPos);

		class_243 forward = class_243.method_1030(camera.method_19329(), camera.method_19330()).method_1029();
		class_243 right = forward.method_1036(new class_243(0.0D, 1.0D, 0.0D));
		if (right.method_1027() < 1.0E-6D) {
			right = class_243.method_1030(0.0F, camera.method_19330() + 90.0F).method_1029();
		} else {
			right = right.method_1029();
		}

		class_243 up = right.method_1036(forward).method_1029();

		double x = cameraToTarget.method_1026(right);
		double y = cameraToTarget.method_1026(up);
		double z = cameraToTarget.method_1026(forward);
		if (z <= 0.01D) {
			return null;
		}

		double fov = getCurrentFov(client, tickDelta);
		double tanHalfFov = Math.tan(Math.toRadians(fov * 0.5D));
		if (tanHalfFov <= 0.0D) {
			return null;
		}

		int width = client.method_22683().method_4486();
		int height = client.method_22683().method_4502();
		if (width <= 0 || height <= 0) {
			return null;
		}

		double aspect = (double) width / (double) height;
		double ndcX = x / (z * tanHalfFov * aspect);
		double ndcY = y / (z * tanHalfFov);
		if (Double.isNaN(ndcX) || Double.isNaN(ndcY)) {
			return null;
		}

		// Если цель за пределами экрана, не подменяем позицию прицела искусственно.
		if (Math.abs(ndcX) > 1.0D || Math.abs(ndcY) > 1.0D) {
			return null;
		}

		float screenX = (float) ((ndcX * 0.5D + 0.5D) * width);
		float screenY = (float) ((0.5D - ndcY * 0.5D) * height);
		return new class_241(screenX, screenY);
	}

	private static void cycleDynamicPreset(class_310 client) {
		if (client == null || client.field_1724 == null || client.field_1755 != null) {
			return;
		}

		CameraConfig config = CameraConfigManager.getConfig().copy();
		String nextId = DynamicPreset.nextId(config.dynamicPreset);
		DynamicPreset preset = DynamicPreset.byId(nextId);
		preset.applyTo(config);
		CameraConfigManager.replaceAndSave(config);
		client.field_1724.method_7353(modPrefix(class_2561.method_43470("Пресет динамики: " + preset.id())), true);
	}

	private static double getCurrentFov(class_310 client, float tickDelta) {
		if (client.field_1773 instanceof GameRendererAccessor accessor) {
			return accessor.tpcamera$invokeGetFov(client.field_1773.method_19418(), tickDelta, true);
		}

		return client.field_1690.method_41808().method_41753();
	}

	private static void drawCrosshair(class_332 context, int x, int y) {
		int outline = 0xE0000000;
		int core = 0xFFFFFFFF;
		context.method_25294(x - 5, y, x + 6, y + 1, outline);
		context.method_25294(x, y - 5, x + 1, y + 6, outline);
		context.method_25294(x - 4, y, x + 5, y + 1, core);
		context.method_25294(x, y - 4, x + 1, y + 5, core);
	}

	public static void openConfigScreen(class_310 client) {
		if (client == null) {
			return;
		}

		client.method_1507(new CameraConfigScreen(client.field_1755));
	}

	public static class_2561 modPrefix(class_2561 message) {
		return class_2561.method_43470("[TP Камера] ").method_10852(message);
	}
}
