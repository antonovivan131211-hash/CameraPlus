package ru.tpcamera.mixin.client;

import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_757.class)
public interface GameRendererAccessor {
	@Invoker("getFov")
	double tpcamera$invokeGetFov(class_4184 camera, float tickDelta, boolean changingFov);
}
