package ru.tpcamera.mixin.client;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.tpcamera.accessor.CameraAccessor;
import ru.tpcamera.camera.DynamicMotion;
import ru.tpcamera.config.CameraConfig;
import ru.tpcamera.config.CameraConfigManager;

@Mixin(class_4184.class)
public abstract class CameraMixin implements CameraAccessor {
	@Unique
	private static final double TPCAMERA_VANILLA_DISTANCE = 4.0D;

	@Unique
	private static final double TPCAMERA_MIN_DISTANCE = 0.1D;

	@Unique
	private static final double TPCAMERA_COLLISION_MARGIN = 0.08D;

	@Unique
	private static final double TPCAMERA_SPEED_FOR_MAX_INERTIA = 0.35D;

	@Unique
	private static final double TPCAMERA_SPRINT_SPEED = 0.28D;

	@Unique
	private static double tpcamera$lastEntitySpeed = 0.0D;

	@Unique
	private boolean tpcamera$hasSmoothingState;

	@Unique
	private double tpcamera$smoothedDistance;

	@Unique
	private double tpcamera$smoothedOffsetX;

	@Unique
	private double tpcamera$smoothedOffsetY;

	@Unique
	private double tpcamera$smoothedOffsetZ;

	@Unique
	private double tpcamera$motionTime;

	@Unique
	private double tpcamera$smoothedAcceleration;

	@Unique
	private double tpcamera$lastHorizontalSpeed;

	@Shadow
	private float yaw;

	@Shadow
	private float pitch;

	@Shadow
	protected abstract void setRotation(float yaw, float pitch);

	@Shadow
	protected abstract void setPos(double x, double y, double z);

	@Inject(method = "update", at = @At("HEAD"))
	private void tpcamera$resetStateWhenInactive(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
		if (!thirdPerson || !CameraConfigManager.getConfig().enabled) {
			this.tpcamera$hasSmoothingState = false;
			this.tpcamera$motionTime = 0.0D;
			this.tpcamera$smoothedAcceleration = 0.0D;
			this.tpcamera$lastHorizontalSpeed = 0.0D;

			if (focusedEntity == null) {
				tpcamera$lastEntitySpeed = 0.0D;
				return;
			}

			class_243 velocity = focusedEntity.method_18798();
			tpcamera$lastEntitySpeed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
		}
	}

	@Inject(method = "update", at = @At("RETURN"))
	private void tpcamera$applyCustomOffsets(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
		if (!thirdPerson || focusedEntity == null) {
			return;
		}

		CameraConfig config = CameraConfigManager.getConfig();
		if (!config.enabled) {
			return;
		}

		class_243 velocity = focusedEntity.method_18798();
		double horizontalSpeed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
		tpcamera$lastEntitySpeed = horizontalSpeed;

		double smoothingAlpha = this.tpcamera$computeSmoothingAlpha(config, horizontalSpeed);
		DynamicMotion motion = this.tpcamera$computeDynamicMotion(config, horizontalSpeed);

		float targetYaw = this.yaw + (float) config.yawOffset + motion.yawOffset;
		float targetPitch = (float) class_3532.method_15350(
			this.pitch + config.pitchOffset + motion.pitchOffset,
			CameraConfig.MIN_PITCH_OFFSET,
			CameraConfig.MAX_PITCH_OFFSET
		);

		double targetDistance = Math.max(TPCAMERA_MIN_DISTANCE, TPCAMERA_VANILLA_DISTANCE + config.distanceOffset + motion.distanceOffset);
		double smoothedDistance = this.tpcamera$smoothDistance(targetDistance, config, smoothingAlpha);

		double smoothedOffsetX = this.tpcamera$smoothValue(this.tpcamera$smoothedOffsetX, config.offsetX, smoothingAlpha);
		double smoothedOffsetY = this.tpcamera$smoothValue(this.tpcamera$smoothedOffsetY, config.offsetY, smoothingAlpha);
		double smoothedOffsetZ = this.tpcamera$smoothValue(this.tpcamera$smoothedOffsetZ, config.offsetZ, smoothingAlpha);
		this.tpcamera$smoothedOffsetX = smoothedOffsetX;
		this.tpcamera$smoothedOffsetY = smoothedOffsetY;
		this.tpcamera$smoothedOffsetZ = smoothedOffsetZ;

		class_243 basePos = focusedEntity.method_5836(tickDelta);
		class_243 desiredPos = this.tpcamera$buildDesiredPosition(
			basePos,
			targetYaw,
			targetPitch,
			smoothedDistance,
			smoothedOffsetX + motion.offsetX,
			smoothedOffsetY + motion.offsetY,
			smoothedOffsetZ + motion.offsetZ,
			config.lockHorizontalDistance
		);

		class_243 finalPos = config.enableCollision
			? this.tpcamera$clipToWorld(focusedEntity, basePos, desiredPos)
			: desiredPos;

		this.setPos(finalPos.field_1352, finalPos.field_1351, finalPos.field_1350);
		this.setRotation(targetYaw, targetPitch);
	}

	@Unique
	private double tpcamera$computeSmoothingAlpha(CameraConfig config, double horizontalSpeed) {
		double alpha = 1.0D - config.smoothness;

		if (config.enableCameraInertia) {
			double speedFactor = class_3532.method_15350(horizontalSpeed / TPCAMERA_SPEED_FOR_MAX_INERTIA, 0.0D, 1.0D);
			double inertiaSlowdown = 1.0D - config.cameraInertia * speedFactor * 0.85D;
			alpha *= class_3532.method_15350(inertiaSlowdown, 0.08D, 1.0D);
		}

		return class_3532.method_15350(alpha, 0.02D, 1.0D);
	}

	@Unique
	private double tpcamera$smoothDistance(double targetDistance, CameraConfig config, double alpha) {
		if (!this.tpcamera$hasSmoothingState) {
			this.tpcamera$smoothedDistance = targetDistance;
			this.tpcamera$smoothedOffsetX = config.offsetX;
			this.tpcamera$smoothedOffsetY = config.offsetY;
			this.tpcamera$smoothedOffsetZ = config.offsetZ;
			this.tpcamera$hasSmoothingState = true;
			return this.tpcamera$smoothedDistance;
		}

		this.tpcamera$smoothedDistance = this.tpcamera$smoothValue(this.tpcamera$smoothedDistance, targetDistance, alpha);
		return this.tpcamera$smoothedDistance;
	}

	@Unique
	private double tpcamera$smoothValue(double current, double target, double alpha) {
		return current + (target - current) * alpha;
	}

	@Unique
	private class_243 tpcamera$buildDesiredPosition(
		class_243 basePos,
		float yaw,
		float pitch,
		double distance,
		double offsetX,
		double offsetY,
		double offsetZ,
		boolean lockHorizontalDistance
	) {
		class_243 forward = class_243.method_1030(pitch, yaw).method_1029();
		class_243 horizontalForward = class_243.method_1030(0.0F, yaw).method_1029();
		class_243 distanceForward = lockHorizontalDistance ? horizontalForward : forward;

		class_243 right = new class_243(0.0D, 1.0D, 0.0D).method_1036(forward);
		if (right.method_1027() < 1.0E-6D) {
			right = class_243.method_1030(0.0F, yaw + 90.0F).method_1029();
		} else {
			right = right.method_1029();
		}

		class_243 up = forward.method_1036(right).method_1029();
		class_243 distanceOffset = distanceForward.method_1021(-distance);
		class_243 localOffsets = right.method_1021(offsetX)
			.method_1019(up.method_1021(offsetY))
			.method_1019(forward.method_1021(offsetZ));
		return basePos.method_1019(distanceOffset).method_1019(localOffsets);
	}

	@Unique
	private class_243 tpcamera$clipToWorld(class_1297 focusedEntity, class_243 start, class_243 target) {
		class_243 delta = target.method_1020(start);
		double distance = delta.method_1033();
		if (distance < 1.0E-6D) {
			return target;
		}

		class_243 normalized = delta.method_1021(1.0D / distance);
		class_3965 hit = focusedEntity.method_37908().method_17742(new class_3959(
			start,
			target,
			class_3959.class_3960.field_17559,
			class_3959.class_242.field_1348,
			focusedEntity
		));

		if (hit.method_17783() == class_239.class_240.field_1333) {
			return target;
		}

		double hitDistance = start.method_1022(hit.method_17784());
		double safeDistance = Math.max(0.0D, hitDistance - TPCAMERA_COLLISION_MARGIN);
		return start.method_1019(normalized.method_1021(safeDistance));
	}

	@Unique
	private DynamicMotion tpcamera$computeDynamicMotion(CameraConfig config, double horizontalSpeed) {
		if (!config.enableDynamicMotion || config.dynamicMotionIntensity <= 0.0D) {
			this.tpcamera$smoothedAcceleration *= 0.85D;
			this.tpcamera$lastHorizontalSpeed = horizontalSpeed;
			return DynamicMotion.ZERO;
		}

		double speedDelta = horizontalSpeed - this.tpcamera$lastHorizontalSpeed;
		this.tpcamera$lastHorizontalSpeed = horizontalSpeed;
		this.tpcamera$smoothedAcceleration += (speedDelta - this.tpcamera$smoothedAcceleration) * 0.18D;

		double speedNorm = class_3532.method_15350(horizontalSpeed / TPCAMERA_SPRINT_SPEED, 0.0D, 1.4D);
		double intensity = config.dynamicMotionIntensity * speedNorm;
		if (intensity <= 1.0E-4D) {
			return DynamicMotion.ZERO;
		}

		this.tpcamera$motionTime += 0.05D + speedNorm * 0.35D;

		double bob = Math.sin(this.tpcamera$motionTime * 2.3D);
		double sway = Math.cos(this.tpcamera$motionTime * 1.5D);
		double lift = Math.abs(Math.sin(this.tpcamera$motionTime * 2.3D));
		double accelImpact = class_3532.method_15350(this.tpcamera$smoothedAcceleration * 8.0D, -1.0D, 1.0D);

		double dynamicX = sway * 0.09D * intensity + accelImpact * 0.03D * config.dynamicMotionIntensity;
		double dynamicY = lift * 0.07D * intensity;
		double dynamicZ = -lift * 0.05D * intensity;
		double dynamicDistance = -lift * 0.12D * intensity;
		float dynamicYaw = (float) (sway * 1.6D * intensity + accelImpact * 0.8D * config.dynamicMotionIntensity);
		float dynamicPitch = (float) (-bob * 0.9D * intensity - accelImpact * 0.6D * config.dynamicMotionIntensity);

		return new DynamicMotion(dynamicX, dynamicY, dynamicZ, dynamicDistance, dynamicYaw, dynamicPitch);
	}

	@Override
	public double tpcamera$getEntitySpeed() {
		return tpcamera$lastEntitySpeed;
	}

}
