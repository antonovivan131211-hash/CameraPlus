package ru.tpcamera.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.tpcamera.ThirdPersonCameraClient;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
	@Shadow
	@Final
	private class_310 client;

	@Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
	private void tpcamera$hideVanillaCrosshair(class_332 context, CallbackInfo ci) {
		if (ThirdPersonCameraClient.shouldUseThirdPersonCrosshair(this.client)) {
			ci.cancel();
		}
	}
}
